"""
Healthcare Data Visualization - Task 2
VirtualWork

This script reads healthcare_data.csv and creates:
1. Disease distribution
2. Age-group distribution
3. Gender ratio
4. Medication usage

Replace healthcare_data.csv with the cleaned dataset from Task 1
before final submission if you have it.
"""

import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("healthcare_data.csv")

# Basic validation
required = {"Age", "Gender", "Disease", "Medication"}
missing = required - set(df.columns)
if missing:
    raise ValueError(f"Missing required columns: {sorted(missing)}")

# Create age groups
bins = [0, 18, 35, 50, 65, float("inf")]
labels = ["0-18", "19-35", "36-50", "51-65", "65+"]
df["Age_Group"] = pd.cut(df["Age"], bins=bins, labels=labels, right=True)

plt.figure(figsize=(8, 5))
df["Disease"].value_counts().sort_values(ascending=False).plot(kind="bar")
plt.title("Disease Distribution")
plt.xlabel("Disease")
plt.ylabel("Number of Patients")
plt.xticks(rotation=30, ha="right")
plt.tight_layout()
plt.savefig("01_disease_distribution.png", dpi=200)
plt.close()

plt.figure(figsize=(8, 5))
df["Age_Group"].value_counts().reindex(labels).fillna(0).plot(kind="bar")
plt.title("Patients by Age Group")
plt.xlabel("Age Group")
plt.ylabel("Number of Patients")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig("02_age_distribution.png", dpi=200)
plt.close()

plt.figure(figsize=(6, 6))
df["Gender"].value_counts().plot(kind="pie", autopct="%1.1f%%", startangle=90)
plt.title("Gender Ratio")
plt.ylabel("")
plt.tight_layout()
plt.savefig("03_gender_ratio.png", dpi=200)
plt.close()

plt.figure(figsize=(8, 5))
df["Medication"].value_counts().sort_values(ascending=False).plot(kind="bar")
plt.title("Medication Usage")
plt.xlabel("Medication")
plt.ylabel("Number of Patients")
plt.xticks(rotation=30, ha="right")
plt.tight_layout()
plt.savefig("04_medication_usage.png", dpi=200)
plt.close()

print("Visualizations created successfully.")
print("\nDisease distribution:")
print(df["Disease"].value_counts())
print("\nGender ratio:")
print(df["Gender"].value_counts())
print("\nMedication usage:")
print(df["Medication"].value_counts())
