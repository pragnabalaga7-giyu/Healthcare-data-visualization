# Healthcare Data Visualization — Task 2

## Objective
Create visual representations of healthcare data to identify trends and patterns.

## Visualizations
- Disease distribution
- Age distribution
- Gender ratio
- Medication usage

## Files
- `healthcare_data.csv` — sample dataset included so the project can be run immediately.
- `visualize_healthcare_data.py` — Python code that generates all four charts.
- `README.md` — project instructions.

## How to run
1. Install Python packages:
   `pip install pandas matplotlib`
2. Put the cleaned Task 1 dataset in this folder and name it `healthcare_data.csv`.
3. Make sure it contains columns:
   `Age`, `Gender`, `Disease`, `Medication`
4. Run:
   `python visualize_healthcare_data.py`

The script creates four PNG files:
- `01_disease_distribution.png`
- `02_age_distribution.png`
- `03_gender_ratio.png`
- `04_medication_usage.png`

## Important
The CSV included in this package is **synthetic sample data**, created because the actual cleaned dataset was not provided with the Task 2 request. For a final submission based on your internship dataset, replace it with your real cleaned dataset from Task 1.
